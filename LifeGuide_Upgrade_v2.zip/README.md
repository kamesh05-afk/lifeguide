# LifeGuide Upgrade (English + Tamil)

## Update your existing GitHub Pages website
1. Open your existing `lifeguide` repository.
2. Open `index.html` and click the pencil icon.
3. Replace all file contents with the contents of this new `index.html`.
4. Click **Commit changes** and confirm.
5. Wait 1–2 minutes and refresh the published website. If needed, press Ctrl+F5.

## Included
- Responsive modern design for laptop and mobile
- English/Tamil language switching
- Search and category filters
- Seven expanded step-by-step guides
- Local guide finder with optional browser voice input
- No API key, server, or paid AI required

The “Ask LifeGuide” feature matches keywords to the included guides. It is not a real AI model and does not contact a server. Voice input depends on browser support. Review emergency guidance and official links before public launch. In India, call 112 for immediate danger.
